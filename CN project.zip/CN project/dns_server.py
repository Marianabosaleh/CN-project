from scapy.all import *
import socket
import requests

from scapy.layers.dns import DNS, DNSRR

# Server parameters
server_ip = '127.0.0.1'
server_port = 53

# Create a UDP socket for DNS communication
dns_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
dns_socket.bind((server_ip, server_port))
print(f"DNS server listening on {server_ip}:{server_port}")

# Loop to handle incoming DNS requests
while True:
    # Receive a DNS query from a client
    dns_query, client_address = dns_socket.recvfrom(1024)
    try:
        dns_packet = DNS(dns_query)
        query_name = dns_packet.qd.qname.decode()
        print(f"Received DNS query '{query_name}' from {client_address[0]}:{client_address[1]}")
    except:
        print(f"Received malformed DNS query from {client_address[0]}:{client_address[1]}")

    # Resolve the DNS query and get the corresponding IP address
    # In this example, we use requests to get the IP address for the domain
    if query_name.startswith("www."):
        domain_name = query_name[4:]
    else:
        domain_name = query_name
    try:
        ip_address = socket.gethostbyname(domain_name)
    except:
        ip_address = '0.0.0.0'

    # Construct the DNS response message using Scapy
    dns_response = DNS(id=dns_packet.id, qr=1, aa=1, qd=dns_packet.qd, an=DNSRR(rrname=query_name, ttl=60, rdlen=4, rdata=ip_address))

    # Send the DNS response to the client using Scapy
    dns_socket.sendto(bytes(dns_response), client_address)
    print(f"Sent DNS response '{ip_address}' to {client_address[0]}:{client_address[1]}")
