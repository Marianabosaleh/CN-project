import os
import socket


class TCPServer:
    def __init__(self, host, port):
        self.host = host
        self.port = port

    def start(self):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((self.host, self.port))
        server_socket.listen(1)

        while True:
            conn, addr = server_socket.accept()
            request = conn.recv(1024).decode('utf-8')
            print(request)
            response = self.handle_request(request)
            conn.sendall(response.encode('utf-8'))
            conn.close()

    def handle_request(self, request):
        # Parse the HTTP request
        request_lines = request.strip().split('\r\n')
        method, path, version = request_lines[0].split(' ')
        headers = dict(x.split(': ') for x in request_lines[1:])

        if method == 'GET':
            if path == '/':
                # Get the path to the user's Downloads directory
                downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
                # Get the list of files in the Downloads directory
                files = os.listdir(downloads_dir)
                # Select the first file in the list
                if files:
                    filename = files[0]
                    filepath = os.path.join(downloads_dir, filename)

                    # Download the file
                    with open(filepath, 'rb') as file:
                        content = file.read()

                    # Redirect the request to https://www.africau.edu/images/default/sample.pdf
                    response = "HTTP/1.1 302 Found\r\nLocation:https://www.africau.edu/images/default/sample.pdf\r\n" \
                               "\r\n"
                else:
                    response = "HTTP/1.1 404 Not Found\r\n\r\n"
            else:
                response = "HTTP/1.1 404 Not Found\r\n\r\n"
        else:
            response = "HTTP/1.1 405 Method Not Allowed\r\n\r\n"

        return response


if __name__ == '__main__':
    server = TCPServer('10.9.14.44', 8082)
    server.start()
