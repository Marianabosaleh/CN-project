import socket
import struct

from scapy.layers.dns import DNS, DNSQR

from http_server_tcp import TCPServer



# DNS server parameters
server_ip = '127.0.0.1'
server_port = 53

# Create a UDP socket for DNS communication
dns_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
dns_socket.settimeout(5)

# Construct the DNS query message using Scapy
dns_query = DNS(rd=1, qd=DNSQR(qname='www.google.com'))

# Send the DNS query to the server using Scapy
dns_socket.sendto(bytes(dns_query), (server_ip, server_port))
print(f"Sent DNS query '{dns_query.qd.qname.decode()}' to {server_ip}:{server_port}")

# Receive the DNS response from the server using Scapy
try:
    dns_response = DNS(dns_socket.recv(1024))
    ip_address = dns_response.an.rdata
    print(f"Received DNS response '{ip_address}' from {server_ip}:{server_port}")
except socket.timeout:
    print("DNS query timed out")
except:
    print("Error parsing DNS response")

# Close the socket
dns_socket.close()


MAX_BYTES = 1024

serverPort = 67
clientPort = 68


class DHCP_client(object):
    def client(self):
        print("DHCP client is starting...\n")
        dest = ('<broadcast>', serverPort)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.bind(('127.0.0.1', clientPort))

        print("Send DHCP discovery.")
        data = DHCP_client.discover_get();
        s.sendto(data, dest)

        data, address = s.recvfrom(MAX_BYTES)
        print("Receive DHCP offer.")
        # print(data)

        print("Send DHCP request.")
        data = DHCP_client.request_get();
        s.sendto(data, dest)

        data, address = s.recvfrom(MAX_BYTES)
        print("Receive DHCP pack.\n")
        # print(data)

    def discover_get(self):
        OP = bytes([0x01])
        HTYPE = bytes([0x01])
        HLEN = bytes([0x06])
        HOPS = bytes([0x00])
        XID = bytes([0x39, 0x03, 0xF3, 0x26])
        SECS = bytes([0x00, 0x00])
        FLAGS = bytes([0x00, 0x00])
        CIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        YIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        SIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        GIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        CHADDR1 = bytes([0x00, 0x05, 0x3C, 0x04])
        CHADDR2 = bytes([0x8D, 0x59, 0x00, 0x00])
        CHADDR3 = bytes([0x00, 0x00, 0x00, 0x00])
        CHADDR4 = bytes([0x00, 0x00, 0x00, 0x00])
        CHADDR5 = bytes(192)
        Magiccookie = bytes([0x63, 0x82, 0x53, 0x63])
        DHCPOptions1 = bytes([53, 1, 1])
        DHCPOptions2 = bytes([50, 4, 0xC0, 0xA8, 0x01, 0x64])

        package = OP + HTYPE + HLEN + HOPS + XID + SECS + FLAGS + CIADDR + YIADDR + SIADDR + GIADDR + CHADDR1 + CHADDR2 + CHADDR3 + CHADDR4 + CHADDR5 + Magiccookie + DHCPOptions1 + DHCPOptions2

        return package

    def request_get(self):
        OP = bytes([0x01])
        HTYPE = bytes([0x01])
        HLEN = bytes([0x06])
        HOPS = bytes([0x00])
        XID = bytes([0x39, 0x03, 0xF3, 0x26])
        SECS = bytes([0x00, 0x00])
        FLAGS = bytes([0x00, 0x00])
        CIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        YIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        SIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        GIADDR = bytes([0x00, 0x00, 0x00, 0x00])
        CHADDR1 = bytes([0x00, 0x0C, 0x29, 0xDD])
        CHADDR2 = bytes([0x5C, 0xA7, 0x00, 0x00])
        CHADDR3 = bytes([0x00, 0x00, 0x00, 0x00])
        CHADDR4 = bytes([0x00, 0x00, 0x00, 0x00])
        CHADDR5 = bytes(192)
        Magiccookie = bytes([0x63, 0x82, 0x53, 0x63])
        DHCPOptions1 = bytes([53, 1, 3])
        DHCPOptions2 = bytes([50, 4, 0xC0, 0xA8, 0x01, 0x64])
        DHCPOptions3 = bytes([54, 4, 0xC0, 0xA8, 0x01, 0x01])

        package = OP + HTYPE + HLEN + HOPS + XID + SECS + FLAGS + CIADDR + YIADDR + SIADDR + GIADDR + CHADDR1 + CHADDR2 + CHADDR3 + CHADDR4 + CHADDR5 + Magiccookie + DHCPOptions1 + DHCPOptions2 + DHCPOptions3

        return package

class TCPClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def send_request(self, request):
        self.socket.connect((self.host, self.port))
        self.socket.sendall(request.encode('utf-8'))
        response = self.socket.recv(1024).decode('utf-8')
        self.socket.close()
        return response


if __name__ == '__main__':
    client = TCPClient('localhost', 8082)
    request = "GET / HTTP/1.1\r\nHost: localhost:8082\r\n\r\n"
    response = client.send_request(request)
    print(response)
    dhcp_client = DHCP_client()
    dhcp_client.client()
