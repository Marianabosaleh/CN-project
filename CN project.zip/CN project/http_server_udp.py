import os
import random
import socket
import time

class UDPServer:
    def __init__(self, host, port):
        self.host = '127.0.0.1'
        self.port = 67
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.client_address = '127.0.0.1'
        self.expected_seq_num = 0
        self.window_size = 5
        self.send_buffer = []
        self.receive_buffer = []
        self.last_ack_sent = -1
        self.last_packet_received_time = time.time()
        self.congestion_window_size = 10
        self.slow_start_threshold = 100
        self.bytes_sent_since_last_ack = 0
        self.congestion_window = []

    def start(self):
        while True:
            self.receive_packet()
            self.check_timeout()
            self.send_packets()

    def receive_packet(self):
        packet, client_address = self.server_socket.recvfrom(1024)
        packet_data = packet.decode('utf-8').split('|')
        seq_num = int(packet_data[0])
        ack_num = int(packet_data[1])
        packet_type = packet_data[2]
        payload = packet_data[3]
        if packet_type == 'ACK':
            # Update slow start threshold and congestion window
            if ack_num > self.last_ack_sent:
                bytes_acked = sum(len(packet) for packet in self.congestion_window[:ack_num - self.last_ack_sent])
                self.last_ack_sent = ack_num
                self.congestion_window = self.congestion_window[ack_num - self.last_ack_sent:]
                if self.bytes_sent_since_last_ack > bytes_acked:
                    self.bytes_sent_since_last_ack -= bytes_acked
                else:
                    self.bytes_sent_since_last_ack = 0
                if self.bytes_sent_since_last_ack >= self.slow_start_threshold:
                    self.congestion_window_size += 1
                else:
                    self.congestion_window_size = len(self.congestion_window)

        if packet_type == 'SYN':
            self.client_address = client_address
            self.expected_seq_num = seq_num + 1
            self.send_packet(0, self.expected_seq_num, 'SYN-ACK', '')

        elif packet_type == 'ACK':
            self.last_packet_received_time = time.time()
            if ack_num > self.last_ack_sent:
                self.send_buffer = self.send_buffer[ack_num - self.last_ack_sent:]
                self.last_ack_sent = ack_num

        elif packet_type == 'DATA':
            if seq_num == self.expected_seq_num:
                self.receive_buffer.append(payload)
                self.expected_seq_num += 1
                self.send_packet(seq_num, self.expected_seq_num, 'ACK', '')
            else:
                self.send_packet(self.expected_seq_num - 1, self.expected_seq_num, 'ACK', '')

    def check_timeout(self):
        if self.send_buffer and time.time() - self.last_packet_received_time > 0.1:
            self.last_packet_received_time = time.time()
            for i, packet in enumerate(self.send_buffer):
                if i == self.window_size:
                    break
                seq_num, payload = packet
                self.send_packet(seq_num, self.expected_seq_num, 'DATA', payload)

    def send_packets(self):
        while len(self.send_buffer) < self.window_size and self.receive_buffer:
            payload = self.receive_buffer.pop(0)
            self.send_buffer.append((self.expected_seq_num, payload))
            self.send_packet(self.expected_seq_num, self.expected_seq_num + 1, 'DATA', payload)
            self.expected_seq_num += 1

    def send_packet(self, seq_num, ack_num, packet_type, payload):
        packet = f'{seq_num}|{ack_num}|{packet_type}|{payload}'.encode('utf-8')

        # Add congestion control logic
        if len(self.congestion_window) >= self.congestion_window_size:
            return  # Congestion window full

        if self.bytes_sent_since_last_ack >= self.slow_start_threshold:
            # Congestion avoidance mode
            packet_size = len(packet)
            if packet_size > self.bytes_sent_since_last_ack:
                packet_size = self.bytes_sent_since_last_ack
            self.bytes_sent_since_last_ack -= packet_size
            self.congestion_window.append(packet[:packet_size])
        else:
            # Slow start mode
            self.bytes_sent_since_last_ack += len(packet)
            self.congestion_window.append(packet)

        if random.random() < 0.9:  # simulate packet loss
            self.server_socket.sendto(packet, self.client_address)

    def handle_request_re(self, request):
        # Parse the HTTP request
        request_lines = request.strip().split('\r\n')
        method, path, version = request_lines[0].split(' ')
        headers = dict(x.split(': ') for x in request_lines[1:])

        if method == 'GET':
            if path == '/':
                # Get the path to the user's Downloads directory
                downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
                # Get the list of files in the Downloads directory
                files = os.listdir(downloads_dir)
                # Select the first file in the list
                if files:
                    filename = files[0]
                    filepath = os.path.join(downloads_dir, filename)

                    # Download the file
                    with open(filepath, 'rb') as file:
                        content = file.read()

                    # Redirect the request to http://www.example.com
                    response = "HTTP/1.1 302 Found\r\nLocation: http://www.africau.edu/images/default/sample.pdf\r\n\r\n"
                    # Send the response and wait for an ACK
                    ack_received = False
                    while not ack_received:
                        self.socket.sendto(response.encode('utf-8'), self.client_address)
                        try:
                            response, server_address = self.socket.recvfrom(1024)
                            response_str = response.decode('utf-8')
                            if response_str.startswith("ACK"):
                                ack_received = True
                        except socket.timeout:
                            pass
                else:
                    response = "HTTP/1.1 404 Not Found\r\n\r\n"

                    # Send the response and wait for an ACK
                    ack_received = False
                    while not ack_received:
                        self.socket.sendto(response.encode('utf-8'),self.client_address)
                        try:
                            response, server_address = self.socket.recvfrom(1024)
                            response_str = response.decode('utf-8')
                            if response_str.startswith("ACK"):
                                ack_received = True
                        except socket.timeout:
                            pass
            else:
                response = "HTTP/1.1 404 Not Found\r\n\r\n"

                # Send the response and wait for an ACK
                ack_received = False
                while not ack_received:
                    self.socket.sendto(response.encode('utf-8'),self.client_address)
                    try:
                        response, server_address = self.socket.recvfrom(1024)
                        response_str = response.decode('utf-8')
                        if response_str.startswith("ACK"):
                            ack_received = True
                    except socket.timeout:
                        pass
        else:
            response = "HTTP/1.1 405 Method Not Allowed\r\n\r\n"

            # Send the response and wait for an ACK
            ack_received = False
            while not ack_received:
                self.socket.sendto(response.encode('utf-8'), self.client_address)
                try:
                    response, server_address = self.socket.recvfrom(1024)
                    response_str = response.decode('utf-8')
                    if response_str.startswith("ACK"):
                        ack_received = True
                except socket.timeout:
                    pass

        # Send an ACK for the request
        self.socket.sendto("ACK".encode('utf-8'),self.client_address)

        def handle_request_flow(self, request):
            # Parse the HTTP request
            request_lines = request.strip().split('\r\n')
            method, path, version = request_lines[0].split(' ')
            headers = dict(x.split(': ') for x in request_lines[1:])

            if method == 'GET':
                if path == '/':
                    # Get the path to the user's Downloads directory
                    downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
                    # Get the list of files in the Downloads directory
                    files = os.listdir(downloads_dir)
                    # Select the first file in the list
                    if files:
                        filename = files[0]
                        # Open the file and read its contents
                        with open(os.path.join(downloads_dir, filename), 'rb') as f:
                            file_contents = f.read()
                        # Send the file contents back to the client
                        response = "HTTP/1.1 302 Found\r\nLocation: https://doc-08-3s-docs.googleusercontent.com/docs/securesc/7rn5l4h60511es0c0hp47jh6vn8q37uf/1qihph3a9di0vso616l0trc7mh862bkc/1678719675000/17573061616771623606/17573061616771623606/1B5kOIFmfz7O1TC167kz4q5D2WB1LjFXU?e=download&ax=AB85Z1BZ7GmwKd99_8I1uqm6TFD8MIuJ6DzykQAfkZJwdmDaAj8weyoMzJ7KyxqDT5str6rBde6pwciiJEyOlhjC1kN25LULnpcuJG7LA7fBtYHk_5wELIMAeXgyUwaXMAguQwKIUdtBR43nfAv1C0w8u-BXjixk6DmqR-vqCewUz2___Jy-y8ayva_c1RlqfISemN6Ri2QieB83cpZfbowXD3TyqzNH8_0kK2ykQodrwM8VBDkeS9m3S8Gnou2PH_W1xyvvHkHHSf0NoHC3pcD5tLlMO8ar-Kai6zXNJ0lLXbOtcV-Mvr0Q-yQ8SwG_ZC2LroH5wpHtiyTE_-b2uS7sy1Jk71zdPGyzWNsggirMiEY6AZJZwtAuYcaa6LxkuWsKUnLqnSJcLBZ1AoYTDYXVxAQvcFnxzCYwVamzD4x8LHovWZNP7aILGpY-4yOVJzRuuse85dv_k39lpod7KpcF9Vjg82Qcb7DOuqy2kzv-XHsZDG15xL1JyQ3jGiA0aj9ciICmoK6mRYNElztqBjqXCJxZYOsJiA6tizBMNx7XOXUAM7Dr1WOBiuB9wPM8qlx8SewWcXRDrwRjuzlxq8bYNnkIhxEx8GpWbHxPi-VZcNgPn4LU76RoNQUuWGWvrxS6W06hu9ZmGwnO9ajIqvl7LXhgfU49ENurX8DdwgWTcqdadtFm28HkhlAtkd51UJ8bAIim4543xwMowdUU2G8iIzliHoZEelpW09oYo5JcGMUQe4oSMCCbQpv3TK4KOobI9XreChPb-LL4VIZCXuPr_XXdz5tf82r9bouPlICu8b_aOVxb8MxpA1jj_x4KQa_zm5zhv_gzrlWGX9AJ5i4O8Pj2M2ifkL3kosftGZugafXK82NcnHCXo-ZHXxQ_hpPbhQ&uuid=0a1590d1-aa35-469f-807a-7d857c4cb1d6&authuser=0&nonce=4vt1stosq9e46&user=17573061616771623606&hash=4h7csub6sfq4tqg7rka2oa3v7filbant\r\n\r\n"

                        self.send_data(response.encode('utf-8') + file_contents)
                    else:
                        # No files in the Downloads directory
                        response = 'HTTP/1.1 404 Not Found\r\n\r\n'
                        self.send_data(response.encode('utf-8'))
                else:
                    # Unsupported path
                    response = 'HTTP/1.1 404 Not Found\r\n\r\n'
                    self.send_data(response.encode('utf-8'))
            else:
                # Unsupported method
                response = 'HTTP/1.1 405 Method Not Allowed\r\n\r\n'
                self.send_data(response.encode('utf-8'))

        def send_data(self, data):
            # Split data into packets and add to send buffer
            seq_num = self.expected_seq_num
            while data:
                payload, data = data[:1024], data[1024:]
                self.send_buffer.append((seq_num, payload))
                seq_num += 1

        def stop(self):
            self.server_socket.close()


import socket


def main():
    # create a UDP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # bind the socket to a specific address and port
    server_address = ('localhost', 5000)
    server_socket.bind(server_address)

    print(f"UDP server listening on {server_address}")

    # receive and process incoming messages
    while True:
        data, client_address = server_socket.recvfrom(1024)
        print(f"Received message: {data.decode()} from {client_address}")

        response = "Hello from the server!"
        server_socket.sendto(response.encode(), client_address)


if __name__ == '__main__':
    # create a UDP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # bind the socket to a specific address and port
    server_address = ('localhost', 6000)
    server_socket.bind(server_address)

    print(f"UDP server listening on {server_address}")

    # receive and process incoming messages
    while True:
        data, client_address = server_socket.recvfrom(1024)
        print(f"Received message: {data.decode()} from {client_address}")

        response = "Hello from the server!"
        server_socket.sendto(response.encode(), client_address)
